#################### Librairies ####################

from tkinter import Tk, IntVar, StringVar, Label, Radiobutton, Canvas, OptionMenu, Button
import os
import time
from threading import Thread
from functools import partial

class class_affichage(Thread):

    def __init__(self):
        
        Thread.__init__(self)

    def run(self):
        self.fen_menu = Tk()
        self.fen_menu.geometry('600x600')  # Taille de la fenetre
        self.fen_menu.title('Menu Puissance 4')   # Titre de la fenetre
        self.fen_menu.config(bg = 'white')  # Couleur du fond de la fenetre

        self.Var_Mode_Jeu = IntVar()
        self.Var_Couleur_J1 = StringVar()
        self.Var_Couleur_J2 = StringVar()

        # Titre Principal
        Canvas_Titre_Entete = Canvas(self.fen_menu, width=540, height=45, highlightthickness=0, background='white')
        Canvas_Titre_Entete.place(x = 30, y = 15)

        Canvas_Titre_Entete.create_rectangle(1,1,539,44)
        Canvas_Titre_Entete.create_text(270, 22.5, text = "Selection du mode de Jeu", font = ('Times', '24'))

        # Local
        Canvas_Titre_Local = Canvas(self.fen_menu, width=180, height=30, highlightthickness=0, background='white')
        Canvas_Titre_Local.place(x = 210, y = 75)

        Canvas_Titre_Local.create_rectangle(1,1,179,29)
        Canvas_Titre_Local.create_text(90, 15, text ="Local")

        # En ligne
        Canvas_Titre_Online = Canvas(self.fen_menu, width=180, height=30, highlightthickness=0, background='white')
        Canvas_Titre_Online.place(x = 210, y = 315)

        Canvas_Titre_Online.create_rectangle(1,1,179,29)
        Canvas_Titre_Online.create_text(90, 15, text ="En-Ligne")

        # Personnalisation
        Canvas_Titre_Perso = Canvas(self.fen_menu, width=180, height=30, highlightthickness=1, background='white')
        Canvas_Titre_Perso.place(x = 210, y = 435)

        Canvas_Titre_Perso.create_rectangle(1,1,179,29)
        Canvas_Titre_Perso.create_text(90, 15, text ="Personnalisation")
    
        #Bouton Radio pour selectionner le mode de jeu
        Radiobutton(self.fen_menu, variable = self.Var_Mode_Jeu, text = "1 Screen", value = 1).place(x = 270, y = 150)
        Radiobutton(self.fen_menu, variable = self.Var_Mode_Jeu, text = "Bot", value = 2).place(x = 400, y = 150)
        Radiobutton(self.fen_menu, variable = self.Var_Mode_Jeu, text = "2 Screen P2P", value = 3).place(x = 270, y = 220)  
        Radiobutton(self.fen_menu, variable = self.Var_Mode_Jeu, text = "Online", value = 4).place(x = 270, y = 370)    
    
        #Selection de la couleur des jetons des deux joueurs(coté client)
        self.listeOptions = ('Rouge','Jaune','Bleu','Vert','Orange','Magenta','Noir')
        self.Var_Couleur_J1.set(self.listeOptions[0])
        self.Var_Couleur_J2.set(self.listeOptions[1])

        Label(self.fen_menu, text = "Couleur Jeton J1 :").place(x = 50, y = 520)
        OptionMenu(self.fen_menu, self.Var_Couleur_J1, *self.listeOptions).place(x = 150, y = 513)
    
        Label(self.fen_menu, text = "Couleur Jeton J2 :").place(x = 400, y = 520)
        OptionMenu(self.fen_menu, self.Var_Couleur_J2, *self.listeOptions).place(x = 500, y = 513)

        #Bouton jouer
        Button(self.fen_menu, text = "Jouer", command = partial(self.func_bouton_jouer)).place(x = 270, y = 500)

        self.fen_menu.mainloop()

    def func_bouton_jouer(self):
        self.fen_menu.destroy()                     #destruction de la fenetre
        Num_Mode_Jeu = self.Var_Mode_Jeu.get()
        Couleur_Jeton_J1 = self.Var_Couleur_J1.get()
        Couleur_Jeton_J2 = self.Var_Couleur_J2.get()

        for i in range(0,7):
            if self.listeOptions[i] == Couleur_Jeton_J1:
                Indice_Couleur_J1 = str(i)

            if self.listeOptions[i] == Couleur_Jeton_J2:
                Indice_Couleur_J2 = str(i)


        if Num_Mode_Jeu == 1:
            text = "I.py " + Indice_Couleur_J1 + " " + Indice_Couleur_J2
            
        elif Num_Mode_Jeu == 2:
            text = "IV.py " + Indice_Couleur_J1 + " " + Indice_Couleur_J2

        elif Num_Mode_Jeu == 3:
            text = "I.py " + Indice_Couleur_J1 + " " + Indice_Couleur_J2

        elif Num_Mode_Jeu == 4:
            text = "II.py " + Indice_Couleur_J1 + " " + Indice_Couleur_J2

        os.system(text)

        
        

class class_ping_server(Thread):

    def __init__(self):
        
        Thread.__init__(self)

    def run(self):
        while True:
            self.hostname = "cryptek.freeboxos.fr"
            self.response = os.system("ping " + self.hostname)
            if self.response == 0:
                self.pingstatus = "Network Active"
                print(self.pingstatus)
            else:
                self.pingstatus = "Network Error"
                print(self.pingstatus)
            time.sleep(20)


Thread_affichage = class_affichage()
Thread_affichage.start()
#Thread_ping_server = class_ping_server()
#Thread_ping_server.start()

