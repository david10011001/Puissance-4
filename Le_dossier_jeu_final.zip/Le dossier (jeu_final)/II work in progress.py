from tkinter import Tk, Canvas, Button, DISABLED, NORMAL
import pickle
import random
import os
#from PIL import ImageTk
import time
from functools import partial
import socket
from threading import Thread

################################################## Class ##################################################
     

class attente (Thread):

    def __init__(self):

        Thread.__init__(self)

        self.case_adversaire = None
        self.serveur = serveur
        self.reception()

    def reception (self):
        
        global Liste
  
        print("En attente d'un message de adversaire ...")  # Indicateur
        self.case_adversaire = self.serveur.recv(1024)
        self.case_adversaire = self.case_adversaire.decode("utf8")
        #time.sleep(1)
        print("Message recu")   # Indicateur

        # Decompose le message recu pour avoir les deux coordonnes (x et y)
        self.colonne = int(self.case_adversaire[0])
        self.ligne = int(self.case_adversaire[1])

        # Enregistre le coup joue par l'adv
        Liste[self.ligne][self.colonne] = 1

        # Affiche le coup jouer par l'adversaire graphiquement
        self.changement_couleur_cercle()

        # Mon tour de jouer donc debloquer boutons de jeu
        deblocage_controles()

        self.reception()

    # Dessine un cercle de la couleur de l'adversaire aux coordonnees recue          
    def changement_couleur_cercle (self):

        global Couleur_Advairsaire
             
        Tab_ligne1 = [8, 78, 148, 218, 288, 358, 428, 498]
        Tab_ligne2 = [62, 132, 202, 272, 342, 412, 482, 552]

        ccol.create_oval(Tab_ligne1[self.colonne], Tab_ligne1[self.ligne], Tab_ligne2[self.colonne], Tab_ligne2[self.ligne],width = 0, fill = Couleur_Advairsaire)

# Affichage + Fonction liees aux boutons
class fenetre (Thread):

    def __init__(self):
        
        Thread.__init__(self)

        self.Colonne_selectionnee = 0

    def run (self):

        global ccol, Joueur, Bt_OK, fleche_vers_gauche, fleche_vers_droite
   
        self.interface = Tk()
        self.interface.geometry('1000x600')  # Taille de la fenetre
        self.interface.title('Jeu du Puissance 42')   # Titre de la fenetre
        self.interface.config(bg = 'white')  # Couleur du fond de la fenetre
        
        
        #################### Creation des Canvas ####################

        ########## Canevas texte ##########

        zone_canvas_droite = Canvas(self.interface, width=300, height=150, highlightthickness=0, background='white')
        zone_canvas_droite.place(x = 600, y = 90)

        text_attribution_joueur = zone_canvas_droite.create_text(100,10, text = '', font = '50')
        text_tour_joueur = zone_canvas_droite.create_text(100,70, text = '', font = '50')

        ########## Canevas des fleches ##########

        self.zone_fleche = Canvas(self.interface, width = 560, height = 70, highlightthickness = 0, bg = 'white')
        self.zone_fleche.place(x = 20, y = 20)

        self.zone_fleche.create_polygon((5,20,35,55,65,20), fill = 'tan')

        ########## Canvas grille de jeu ##########

        ccol = Canvas(self.interface, width=560, height=490, highlightthickness=1,highlightbackground = 'black', background='navy') 
        ccol.place(x = 20, y = 90)

        # Creer les lignes de separations (trait noirs)
        for i in [70, 140, 210, 280, 350, 420] :
            ccol.create_line(0, i, 560, i)

        # Creer les colonnes de separations (trait noirs)
        for i in [70, 140, 210, 280, 350, 420, 490]:
            ccol.create_line(i, 0, i, 490)

        # Creer les ronds blancs (x56)
        Tab_point_A = [8, 78, 148, 218, 288, 358, 428, 498]
        Tab_point_B = [62, 132, 202, 272, 342, 412, 482, 552]

        for ligne in range(0,7):
            for colonne in range(0,8):
                ccol.create_oval(Tab_point_A[colonne], Tab_point_A[ligne], Tab_point_B[colonne], Tab_point_B[ligne], width = 0, fill = 'white')

        ########## Creation des boutons ##########

        # Bouton fleche vers droite
        fleche_vers_droite = Button(self.interface, command = self.func_fleche_allant_vers_droite, text = '->')    
        fleche_vers_droite.place(x = 650, y = 250)

        # Bouton fleche vers gauche 
        fleche_vers_gauche = Button(self.interface, command = self.func_fleche_allant_vers_gauche, text = '<-')    
        fleche_vers_gauche.place(x = 600, y = 250)

        # Bouton OK
        Bt_OK = Button(self.interface, command = self.OK, text = 'OK')    
        Bt_OK.place(x = 600, y = 300)

        # Au premier tour, bloquer bouton joueur jouant en deuxieme
        if Joueur == 1:
            
            blocage_controles()
          
        self.interface.mainloop()

    # Dessiner fleche au bonne coordonees  
    def func_fleche_allant_vers_droite(self):

        # Dessiner fleche en blanc sur la fleche 
        self.zone_fleche.create_polygon((5+(self.Colonne_selectionnee)*70, 20, 35+(self.Colonne_selectionnee)*70, 55, 65+(self.Colonne_selectionnee)*70, 20), fill = 'white')   

        # Changer la colonne selectionner modulo 7
        if self.Colonne_selectionnee+1 > 7:

            self.Colonne_selectionnee = 0

        else:

            self.Colonne_selectionnee += 1
        
        self.zone_fleche.create_polygon((5+self.Colonne_selectionnee*70, 20, 35+self.Colonne_selectionnee*70, 55, 65+self.Colonne_selectionnee*70, 20), fill = 'tan')   

    # Dessiner fleche au bonne coordonees
    def func_fleche_allant_vers_gauche(self):

        # Dessiner fleche en blanc sur la fleche
        self.zone_fleche.create_polygon((5+(self.Colonne_selectionnee)*70, 20, 35+(self.Colonne_selectionnee)*70, 55, 65+(self.Colonne_selectionnee)*70, 20), fill = 'white')   

        # Changer la colonne selectionner modulo 7
        if self.Colonne_selectionnee-1 < 0:

            self.Colonne_selectionnee = 7

        else:

            self.Colonne_selectionnee -= 1

        self.zone_fleche.create_polygon((5+self.Colonne_selectionnee*70, 20, 35+self.Colonne_selectionnee*70, 55, 65+self.Colonne_selectionnee*70, 20), fill = 'tan')

    # Affiche le coup jouer par soi et envoie les coordonnees du coup jouer au serveur (xy)
    def OK(self):
        
        global Liste
        
        for self.ligne in range(6,-1,-1):

            if Liste[self.ligne][self.Colonne_selectionnee] == 0:

                Liste[self.ligne][self.Colonne_selectionnee] = 1    # Place le numero du joiueur dans la case disponible/jouee

                self.changement_couleur_cercle() # Fait apparaitre la bonne couleur graphiquement en fonction de la ligne de la colonne et du joueur

                self.envoie()

                blocage_controles()  # Passe en mode attente (desactivation des boutons de jeu), quand tour de l'adv

                break  

    # Changer la couleur graphiquement du bon cercle
    def changement_couleur_cercle(self):
        
        global Couleur_Moi
 
        Tab_ligne1 = [8, 78, 148, 218, 288, 358, 428, 498]
        Tab_ligne2 = [62, 132, 202, 272, 342, 412, 482, 552]

        ccol.create_oval(Tab_ligne1[self.Colonne_selectionnee], Tab_ligne1[self.ligne], Tab_ligne2[self.Colonne_selectionnee], Tab_ligne2[self.ligne],width = 0, fill = Couleur_Moi)    

    # Envoie au server les coordonnees de la case joueur (case) de type (xy)
    def envoie (self):

        msg = str(self.Colonne_selectionnee) + str(self.ligne)
        msg = msg.encode('utf8')
        serveur.sendall(msg)

################################################## Fonctions ##################################################

def func_debut_partie ():
    global Joueur, Couleur_Moi, Couleur_Advairsaire 

    # Recoit mesage du serveur qui indique le demarrage de la partie
    msg_debut = serveur.recv(1024)
    msg_debut = msg_debut.decode("utf8")
    print (msg_debut)   # Indicateur

    # Cas possible : '11' = Lancer partie + Ton tour / '10' = Lancer partie + Tour Adv
    if msg_debut == '11':
        Joueur = 0

    else :
        Joueur = 1



    # Partie des Thread
    affichage = fenetre()
    affichage.start()                  
    Thread = attente() 
    Thread.start()

# Active les boutons pour jouer    
def deblocage_controles():
    
    global Bt_OK, fleche_vers_gauche, fleche_vers_droite
  
    Bt_OK.config(state = NORMAL)
    fleche_vers_droite.config(state = NORMAL)
    fleche_vers_gauche.config(state = NORMAL)

# Desactive les boutons pour jouer
def blocage_controles ():
    
    global Bt_OK, fleche_vers_gauche, fleche_vers_droite

    Bt_OK.config(state = DISABLED)
    fleche_vers_droite.config(state = DISABLED)
    fleche_vers_gauche.config(state = DISABLED)

def func_couleur_jeton(joueur, indice):
    global Couleur_Moi, Couleur_Advairsaire
    
    Couleur= ['red','yellow','blue','green','orange','magenta','black']
    
    if joueur == 1:
        Couleur_Moi = Couleur[indice]
    else:
        Couleur_Advairsaire = Couleur[indice]    

# Connection serveur
host, port = ('cryptek.freeboxos.fr', 25565)

serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try :

    serveur.connect((host,port))
    print("vous etes connecte au server distant")
 
except:

    print("Impossible de se connecter au server distant")


#Init
try:
    Couleur_J1 = int(sys.argv[1])
    Couleur_J2 = int(sys.argv[2])
    func_couleur_jeton(1, Couleur_J1)
    func_couleur_jeton(2, Couleur_J2)
        
except:
    Couleur_Moi = "red"
    Couleur_Advairsaire = "yellow"

######################### Variables #########################
global Liste

Liste =[[0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0]]


func_debut_partie()


