from tkinter import Tk, Canvas, Button, DISABLED, NORMAL, NW, Image, PhotoImage, ACTIVE
import pickle
import random
import os
from PIL import ImageTk
import time
from functools import partial
import socket
from threading import Thread
import sys

################################################## Class ##################################################
     

class attente (Thread):

    def __init__(self):

        Thread.__init__(self)

        self.case_adversaire = None
        self.serveur = serveur
        self.reception()

    def reception (self):
        
        global Liste, zone_canvas_droite, text_tour_joueur, Bt_OK
  
        print("En attente d'un message de adversaire ...")  # Indicateur
        self.case_adversaire = self.serveur.recv(1024)
        self.case_adversaire = self.case_adversaire.decode("utf8")
        #time.sleep(1)
        print("Message recu")   # Indicateur
        
        zone_canvas_droite.itemconfigure(text_tour_joueur, text = "A votre tour de jouer")

        if self.case_adversaire == '1':
            zone_canvas_droite.itemconfigure(text_tour_joueur, text = "Le joueur 1 a gagner")
            Bt_OK.config(state = DISABLED)
            interface.unbind('<Up>')

        elif self.case_adversaire == '2':
            zone_canvas_droite.itemconfigure(text_tour_joueur, text = "Le joueur 2 a gagner")
            Bt_OK.config(state = DISABLED)
            interface.unbind('<Up>')

            

        # Decompose le message recu pour avoir les deux coordonnes (x et y)
        self.colonne = int(self.case_adversaire[0])
        self.ligne = int(self.case_adversaire[1])

        # Enregistre le coup joue par l'adv
        Liste[self.ligne][self.colonne] = 1

        # Affiche le coup jouer par l'adversaire graphiquement
        self.func_annimation_jeton(self.colonne)

        # Mon tour de jouer donc debloquer boutons de jeu
        self.deblocage_controles()

        self.reception()

    # Dessine un cercle de la couleur de l'adversaire aux coordonnees recue          
    def changement_couleur_cercle (self):
        global Couleur_Advairsaire
             
        Tab_ligne1 = [8, 78, 148, 218, 288, 358, 428, 498]
        Tab_ligne2 = [62, 132, 202, 272, 342, 412, 482, 552]

        ccol.create_oval(Tab_ligne1[self.colonne], Tab_ligne1[self.ligne], Tab_ligne2[self.colonne], Tab_ligne2[self.ligne],width = 0, fill = Couleur_Advairsaire)

    # Active les boutons pour jouer    
    def deblocage_controles(self):    
        global Bt_OK
  
        Bt_OK.config(state = NORMAL)
        fen = fenetre()
        interface.bind('<Up>', lambda e: fen.OK())

    # Animation de la chûte du pio
    def func_annimation_jeton(self,colonne):
        global ccol, icl, cercle_anim
        
        cercle_anim = ccol.create_oval(5, 5, 65, 65, fill = "white")    # Creer le pion joué (blanc)
        ccol.tag_lower(cercle_anim) # Place le pion a l'arriere plan

        Bt_OK.config(state = DISABLED)  # Desactive le bouton OK
        #interface.unbind('<Up>')    # Delie le bouton OK

        vitesse_chute = 0.03 # Definition de la vitesse de chute

        couleur = Couleur_Advairsaire

        ccol.itemconfigure(cercle_anim, fill = couleur) # Change la couleur du pion
        ccol.move(cercle_anim, colonne*70, 0)   # Place le cercle selon la colonne jouée
        

        destination_y = 42-(icl[colonne]*7) # Determine la destination (hauteur du pion selon le nombre de pions dans la colonne)
        
        # Selon destination, Anime plus ou moins longtemps la chûte pion
        for i in range (destination_y):
            ccol.move(cercle_anim , 0, 10)  # Descens le pions de 10
            time.sleep(vitesse_chute)   # Attend (vitesse_chute)
            ccol.update() # Actualise l'affichage


        icl[colonne] +=1    # +1 dans la mémoire du nombre de pion dans chaque colonne
        #interface.bind('<Up>', lambda e: self.OK()) # Relie le bouton ok  
        Bt_OK.config(state = ACTIVE)    # Reactive le bouton ok

# Affichage + Fonction liees aux boutons
class fenetre(Thread):

    def __init__(self):
        
        Thread.__init__(self)


    def run (self):

        global ccol, Joueur, Bt_OK, fleche_vers_gauche, fleche_vers_droite, interface, zone_canvas_droite, text_tour_joueur
   
        interface = Tk()
        interface.geometry('1000x600')  # Taille de la fenetre
        interface.title('Jeu du Puissance 4')   # Titre de la fenetre
        interface.config(bg = 'white')  # Couleur du fond de la fenetre
        
        
        #################### Creation des Canvas ####################

        ########## Canvas texte ##########

        zone_canvas_droite = Canvas(interface, width=300, height=150, highlightthickness=0, background='white')
        zone_canvas_droite.place(x = 600, y = 90)

        text_attribution_joueur = zone_canvas_droite.create_text(100,10, text = '', font = '50')
        text_tour_joueur = zone_canvas_droite.create_text(100,70, text = '', font = '50')

        ########## Canvas des fleches ##########

        self.zone_fleche = Canvas(interface, width = 560, height = 70, highlightthickness = 0, bg = 'white')
        self.zone_fleche.place(x = 20, y = 20)

        self.zone_fleche.create_polygon((5,20,35,55,65,20), fill = 'tan')

        ########## Canvas grille de jeu ##########

        self.func_creation_affichage()
        interface.bind('<Up>', lambda e: self.OK())
        interface.bind('<Left>', lambda e: self.func_fleche_allant_vers_gauche())
        interface.bind('<Right>', lambda e: self.func_fleche_allant_vers_droite())

        ########## Creation des boutons ##########

        ### Création des variables correspondant au image des boutons  ###

        # Bouton fleche gauche
        fleche_G = PhotoImage(file = 'Images/fleche_G.png')    # Importe l'image
        fleche_G = fleche_G.subsample(10,10)    # Reduit la taille 

        # Bouton fleche droite
        fleche_D = PhotoImage(file = 'Images/fleche_D.png')
        fleche_D = fleche_D.subsample(10,10)

        # Bouton ok
        img_OK = PhotoImage(file = 'Images/OK.png')
        img_OK = img_OK.subsample(10,10)

        ### Création des boutons ###

        # Bouton fleche droite
        fleche_vers_droite = Button(interface, command = self.func_fleche_allant_vers_droite, image = fleche_D)
        fleche_vers_droite.place(x = 727, y = 250) 
        fleche_vers_droite.config(state = ACTIVE)

        # Bouton fleche gauche
        fleche_vers_gauche = Button(interface, command = self.func_fleche_allant_vers_gauche, image = fleche_G)
        fleche_vers_gauche.place(x = 625, y = 250)
        fleche_vers_gauche.config(state = ACTIVE)

        # Bouton ok
        Bt_OK = Button(interface, command = self.OK, image = img_OK)
        Bt_OK.place(x = 670, y = 300)
        Bt_OK.config(state = ACTIVE)

        # Au premier tour, bloquer bouton joueur jouant en deuxieme
        if Joueur == 1:
            
            self.blocage_controles()
            zone_canvas_droite.itemconfigure(text_tour_joueur, text = "A l'adversaire de jouer")

        else :
            zone_canvas_droite.itemconfigure(text_tour_joueur, text = "A votre tour de jouer")
          
        interface.mainloop()

    # Dessiner fleche au bonne coordonees  
    def func_fleche_allant_vers_droite(self):
        global Colonne_selectionnee

        # Dessiner fleche en blanc sur la fleche 
        self.zone_fleche.create_polygon((5+(Colonne_selectionnee)*70, 20, 35+(Colonne_selectionnee)*70, 55, 65+(Colonne_selectionnee)*70, 20), fill = 'white')   

        # Changer la colonne selectionner modulo 7
        if Colonne_selectionnee+1 > 7:

            Colonne_selectionnee = 0

        else:

            Colonne_selectionnee += 1
        
        self.zone_fleche.create_polygon((5+Colonne_selectionnee*70, 20, 35+Colonne_selectionnee*70, 55, 65+Colonne_selectionnee*70, 20), fill = 'tan')   

    # Dessiner fleche au bonne coordonees
    def func_fleche_allant_vers_gauche(self):
        global Colonne_selectionnee

        # Dessiner fleche en blanc sur la fleche
        self.zone_fleche.create_polygon((5+(Colonne_selectionnee)*70, 20, 35+(Colonne_selectionnee)*70, 55, 65+(Colonne_selectionnee)*70, 20), fill = 'white')   

        # Changer la colonne selectionner modulo 7
        if Colonne_selectionnee-1 < 0:

            Colonne_selectionnee = 7

        else:

            Colonne_selectionnee -= 1

        self.zone_fleche.create_polygon((5+Colonne_selectionnee*70, 20, 35+Colonne_selectionnee*70, 55, 65+Colonne_selectionnee*70, 20), fill = 'tan')

    # Affiche le coup jouer par soi et envoie les coordonnees du coup jouer au serveur (xy)
    def OK(self):
        
        global Liste, zone_canvas_droite, text_tour_joueur
        
        for self.ligne in range(6,-1,-1):

            if Liste[self.ligne][Colonne_selectionnee] == 0:

                Liste[self.ligne][Colonne_selectionnee] = 1    # Place le numero du joiueur dans la case disponible/jouee

                self.func_annimation_jeton(Colonne_selectionnee) # Fait apparaitre la bonne couleur graphiquement en fonction de la ligne de la colonne et du joueur

                self.envoie()

                self.blocage_controles()  # Passe en mode attente (desactivation des boutons de jeu), quand tour de l'adv

                zone_canvas_droite.itemconfigure(text_tour_joueur, text = "A l'adversaire de jouer")

                break  

        
        global Couleur_Moi
 
        Tab_ligne1 = [8, 78, 148, 218, 288, 358, 428, 498]
        Tab_ligne2 = [62, 132, 202, 272, 342, 412, 482, 552]

        ccol.create_oval(Tab_ligne1[Colonne_selectionnee], Tab_ligne1[self.ligne], Tab_ligne2[Colonne_selectionnee], Tab_ligne2[self.ligne],width = 0, fill = Couleur_Moi)    

    def blocage_controles(self):
        global Bt_OK

        Bt_OK.config(state = DISABLED)
        interface.unbind('<Up>')

    def func_creation_affichage(self):
        global ccol, img

        #Création du canvas de la zone de la grille
        ccol = Canvas(interface, width=560, height=490, highlightthickness=1,highlightbackground = 'black', background='white') 
        ccol.place(x = 20, y = 90)
        
        img = ImageTk.PhotoImage(file="Images/Image_grille.png")   #Importe l'image de la grille de jeu
        ccol.create_image(-1, -1, image=img, anchor=NW) #Affiche la grille

    # Animation de la chûte du pio
    def func_annimation_jeton(self,colonne):
        global ccol, icl, cercle_anim
        
        cercle_anim = ccol.create_oval(5, 5, 65, 65, fill = "white")    # Creer le pion joué (blanc)
        ccol.tag_lower(cercle_anim) # Place le pion a l'arriere plan

        Bt_OK.config(state = DISABLED)  # Desactive le bouton OK
        interface.unbind('<Up>')    # Delie le bouton OK

        vitesse_chute = 0.03 # Definition de la vitesse de chute

        couleur = Couleur_Moi

        ccol.itemconfigure(cercle_anim, fill = couleur) # Change la couleur du pion
        ccol.move(cercle_anim, colonne*70, 0)   # Place le cercle selon la colonne jouée
        

        destination_y = 42-(icl[colonne]*7) # Determine la destination (hauteur du pion selon le nombre de pions dans la colonne)
        
        # Selon destination, Anime plus ou moins longtemps la chûte pion
        for i in range (destination_y):
            ccol.move(cercle_anim , 0, 10)  # Descens le pions de 10
            time.sleep(vitesse_chute)   # Attend (vitesse_chute)
            ccol.update() # Actualise l'affichage


        icl[colonne] +=1    # +1 dans la mémoire du nombre de pion dans chaque colonne
        interface.bind('<Up>', lambda e: self.OK()) # Relie le bouton ok  
        Bt_OK.config(state = NORMAL)    # Reactive le bouton ok

    # Envoie au server les coordonnees de la case joueur (case) de type (xy)
    def envoie (self):

        msg = str(Colonne_selectionnee) + str(self.ligne)
        msg = msg.encode('utf8')
        serveur.sendall(msg)

################################################## Fonctions ##################################################

# Lance la partie une fois les deux clients connectés
def func_debut_partie ():
    global Joueur

    # Recoit mesage du serveur qui indique le demarrage de la partie
    msg_debut = serveur.recv(1024)
    msg_debut = msg_debut.decode("utf8")
    print (msg_debut)   # Indicateur

    # Cas possible : '11' = Lancer partie + Ton tour / '10' = Lancer partie + Tour Adv
    if msg_debut == '11':
        Joueur = 0
        
    else :
        Joueur = 1



    # Partie des Thread
    affichage = fenetre()
    affichage.start()                  
    Thread = attente() 
    Thread.start()

# Definit la couleur des jetons selon les arguments de lancement du jeu
def func_couleur_jeton(joueur, indice):
    global Couleur_Moi, Couleur_Advairsaire
    
    Couleur= ['red','yellow','blue','green','orange','magenta','black']
    
    if joueur == 1:
        Couleur_Moi = Couleur[indice]
    else:
        Couleur_Advairsaire = Couleur[indice]    

global Couleur_Advairsaire, Couleur_Moi
Couleur_Moi = ""
Couleur_Advairsaire = ""





# Récupération des valeurs pour la couleur des jetons(si il n'y pas -> couleur par défault)
if __name__ == "__main__":
    # Si valeurs
    try:
        Couleur_J1 = int(sys.argv[1])   #Recup Argument 1
        Couleur_J2 = int(sys.argv[2])   #Recup Argument 2   
        func_couleur_jeton(1, Couleur_J1)   #Regarde a quelle couleur correspond l'argument et change la couleur du jeton
        func_couleur_jeton(2, Couleur_J2)   # ""
        
    # Couleurs par défaults
    except: 
        Couleur_Moi = "red"
        Couleur_Advairsaire = "yellow"




##### Connection serveur #####
host, port = ('cryptek.freeboxos.fr', 25566)

serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try :

    serveur.connect((host,port))
    print("vous etes connecte au server distant")
 
except:

    print("Impossible de se connecter au server distant")


##### Variables #####

global Liste, Colonne_selectionnee



Liste =[[0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0]]

icl = [0,0,0,0,0,0,0,0]

Colonne_selectionnee = 0

func_debut_partie()


