from tkinter import Button, Canvas, Tk, DISABLED, ACTIVE, Menu, Radiobutton, IntVar, Image, NW, PhotoImage
import pickle
import random
import os
import time
from functools import partial
import sys
from PIL import ImageTk

# Coeur du programme
def func_ok():
    global Joueur_en_cours, Liste

    # Par du bas du tableau et remonte de ligne en ligne
    for ligne in range(6,-1,-1):
        # Si la case de cette ligne dans cette colonne la est vide
        if Liste[ligne][Colonne_selectionnee] == 0:

            # Changer la case par le numero du joueur
            Liste[ligne][Colonne_selectionnee] = Joueur_en_cours

            # Lance l'animation de la chûte du pion selon la colonne selectionnee et le joueur en cours
            func_annimation_jeton(Colonne_selectionnee, Joueur_en_cours)

            # Si le joueur qui a joué à gagné
            if func_verification_gagne(Liste) == True:

                # Affiche le joueur qui a gagner
                func_affichage_joueur_gagner(Joueur_en_cours)

                #Desactiver les boutons de jeu
                func_act_desact_bouton_de_jeu("Desactiver")

                # Delie les touches du clavier
                func_lier_delier_touches("de-lier")

                break # Ne pas faire la suite

            # Changement de joueur_en_cours
            func_changement_joueur_en_cours(Joueur_en_cours)

            # Affiche quel joueur doit jouer
            func_affichage_joueur(Joueur_en_cours)

            # Fait jouer le bot
            func_IA()

            break   # Ne pas essayer de jouer dans les lignes au dessus de celle jouer a ce tour ci

    pass

# Remets le programme comme il est au debut (sauf la colonne selectionner)
def func_restart():
    global Liste, Joueur_en_cours, icl

    # Remise variables a zero
    Liste = [[0,0,0,0,0,0,0,0],
             [0,0,0,0,0,0,0,0],
             [0,0,0,0,0,0,0,0],
             [0,0,0,0,0,0,0,0],
             [0,0,0,0,0,0,0,0],
             [0,0,0,0,0,0,0,0],
             [0,0,0,0,0,0,0,0]]


    Joueur_en_cours = 1

    # Memoire nombre de pions par colonne à 0
    icl = [0,0,0,0,0,0,0,0]

    # Affichage ronds blancs
    func_creation_affichage()

    # Affichage quel joueur doit jouer
    func_affichage_joueur(Joueur_en_cours)

    #Activer les boutons de jeu
    func_act_desact_bouton_de_jeu("Activer")

    # Liaison touche <-> fonctions
    func_lier_delier_touches("lier")

# Verifie si presence de quatres jetons de la meme couleur se suivent
def func_verification_gagne(Liste):  
    Gagne = False
    ########################### 4 en colonne ###########################
    for colonne in range (0,8):         # Colonne de gauche a droite
        for ligne in range (6,2,-1):    # Ligne de bas en haut

            if Gagne == False:  # Ne pas verifier si deja gagner

                a = Liste[ligne][colonne]   # a --> Case de coordonnees (ligne, colonne)
                b = Liste[ligne-1][colonne] # b --> Case au dessus de a
                c = Liste[ligne-2][colonne] # c --> Case deux au dessus de a
                d = Liste[ligne-3][colonne] # d --> Case trois au dessus de a

                if a == b and a == c and a == d and a!=0:    # Si a, b, c, d -> egaux -> gagne
                    Gagne = True


    ########################### 4 en ligne ###########################
    for colonne in range (0,5):         # Colonne de gauche a droite
        for ligne in range (6,-1,-1):   # Ligne de bas en haut

            if Gagne == False:  # Ne pas verifier si deja gagner

                a = Liste[ligne][colonne]   # a --> Case de coordonnees (ligne, colonne)
                b = Liste[ligne][colonne+1] # b --> Case un a droite
                c = Liste[ligne][colonne+2] # c --> Case deux a droite de a
                d = Liste[ligne][colonne+3] # d --> Case trois au droite de a

                if a == b and a == c and a == d and a!=0:    #Si a, b, c, d -> egaux -> gagne
                    Gagne = True

    ########################### 4 en diagonale ###########################
                ############# Vers haut droite ##############

    for colonne in range(0,5):      # Colonne de gauche a droite
        for ligne in range(6,2,-1): # Ligne de bas en haut

            if Gagne == False:  # Ne pas verifier si deja gagner

                a = Liste[ligne][colonne]       # a --> Case de coordonnees (ligne, colonne)
                b = Liste[ligne-1][colonne+1]   # b --> Case un en haut a droite
                c = Liste[ligne-2][colonne+2]   # c --> Case deux en haut a droite
                d = Liste[ligne-3][colonne+3]   # d --> Case trois en haut a droite

            if a == b and a == c and a == d and a!=0:   #Si a, b, c, d -> egaux -> gagne
                Gagne = True

    for colonne in range(3,8):      # Colonne de gauche a droite
        for ligne in range(6,2,-1): # Ligne de bas en haut

            if Gagne == False:  # Ne pas verifier si deja gagner

                a = Liste[ligne][colonne]       # a --> Case de coordonnees (ligne, colonne)
                b = Liste[ligne-1][colonne-1]   # b --> Case un en haut a droite
                c = Liste[ligne-2][colonne-2]   # c --> Case deux en haut a droite
                d = Liste[ligne-3][colonne-3]   # d --> Case trois en haut a droite

            if a == b and a == c and a == d and a!=0:   #Si a, b, c, d -> egaux -> gagne
                Gagne = True

    return Gagne    

# Dessiner fleche au bonne coordonees  
def func_fleche_allant_vers_droite():
    global Colonne_selectionnee

    # Dessiner fleche en blanc sur la fleche 
    zone_fleche.create_polygon((5+(Colonne_selectionnee)*70, 20, 35+(Colonne_selectionnee)*70, 55, 65+(Colonne_selectionnee)*70, 20), fill = 'white')   

    # Changer la colonne selectionner modulo 7
    if Colonne_selectionnee+1 > 7:
        Colonne_selectionnee = 0
    else:
        Colonne_selectionnee += 1
    
    zone_fleche.create_polygon((5+Colonne_selectionnee*70, 20, 35+Colonne_selectionnee*70, 55, 65+Colonne_selectionnee*70, 20), fill = 'tan')   

# Dessiner fleche au bonne coordonees
def func_fleche_allant_vers_gauche():
    global Colonne_selectionnee

    # Dessiner fleche en blanc sur la fleche
    zone_fleche.create_polygon((5+(Colonne_selectionnee)*70, 20, 35+(Colonne_selectionnee)*70, 55, 65+(Colonne_selectionnee)*70, 20), fill = 'white')   

    # Changer la colonne selectionner modulo 7
    if Colonne_selectionnee-1 < 0:
        Colonne_selectionnee = 7
    else:
        Colonne_selectionnee -= 1

    zone_fleche.create_polygon((5+Colonne_selectionnee*70, 20, 35+Colonne_selectionnee*70, 55, 65+Colonne_selectionnee*70, 20), fill = 'tan')   

# Affiche quel joueur a gagner
def func_affichage_joueur_gagner(joueur_en_cours):
    if joueur_en_cours == 1:
        zone_canvas_droite.itemconfigure(text_tour_joueur, text = "Le joueur 1 a gagné")
    elif joueur_en_cours == 2:
        zone_canvas_droite.itemconfigure(text_tour_joueur, text = "Le joueur 2 a gagné")
    pass

# Determine la couleur de jeton des joueur selon les arguments de lancement du jeu
def func_couleur_jeton(joueur, indice):
    global Couleur_Jeton_J1, Couleur_Jeton_J2
    
    Couleur= ['red','yellow','blue','green','orange','magenta','black']
    
    if joueur == 1:
        Couleur_Jeton_J1 = Couleur[indice]
    else:
        Couleur_Jeton_J2 = Couleur[indice]      

def func_annimation_jeton(colonne,joueur_en_cours):
    global ccol, icl, cercle_anim

    cercle_anim = ccol.create_oval(5, 5, 65, 65, fill = "white")    # Creer le pion joué (blanc)
    ccol.tag_lower(cercle_anim) # Place le pion a l'arriere plan

    Bt_OK.config(state = DISABLED)  # Desactive le bouton OK
    interface.unbind('<Up>')    # Delie le bouton OK

    vitesse_chute = 0.03    # Definition de la vitesse de chute

    # Regarde le numero du joueur pour savoir sa couleur
    if joueur_en_cours == 1 :
        couleur = Couleur_Jeton_J1

    else:
        couleur = Couleur_Jeton_J2


    ccol.move(cercle_anim, colonne*70, 0)   # Change la couleur du pion
    ccol.itemconfigure(cercle_anim, fill = couleur) # Place le cercle selon la colonne jouée

    destination_y = 42-(icl[colonne]*7) # Determine la destination (hauteur du pion selon le nombre de pions dans la colonne)
    
    # Selon destination, Anime plus ou moins longtemps la chûte pion
    for i in range (destination_y):
        ccol.move(cercle_anim , 0, 10)  # Descens le pions de 10
        time.sleep(vitesse_chute)   # Attend (vitesse_chute)
        ccol.update()   # Actualise l'affichage


    icl[colonne] +=1    # +1 dans la mémoire du nombre de pion dans chaque colonne
    interface.bind('<Up>', lambda e: func_ok()) # Relie le bouton ok  
    Bt_OK.config(state = ACTIVE)    # Reactive le bouton ok

# Lier ou Delier les touches du clavier
def func_lier_delier_touches(x):
    # Lier les touches
    if x == "lier":
        interface.bind('<Left>', lambda e: func_fleche_allant_vers_gauche())
        interface.bind('<Right>', lambda e: func_fleche_allant_vers_droite())
        interface.bind('<Up>', lambda e: func_ok())   

    # Delier les touches
    else :
        interface.unbind('<Up>')

# Change le joueur en cours
def func_changement_joueur_en_cours(joueur):
    global Joueur_en_cours

    if joueur == 1:
        Joueur_en_cours = 2
    elif joueur == 2:
        Joueur_en_cours = 1
    pass

# Afficher quel joueur doit jouer
def func_affichage_joueur(joueur_en_cours):
    if joueur_en_cours == 1 :
        zone_canvas_droite.itemconfigure(text_tour_joueur, text = 'Au tour du joueur 1')
    elif joueur_en_cours == 2:
        zone_canvas_droite.itemconfigure(text_tour_joueur, text = 'Au tour du joueur 2')
    pass

# Affichage de la grille de jeu
def func_creation_affichage():
    global ccol, img

    #Création du canvas de la zone de la grille
    ccol = Canvas(interface, width=560, height=490, highlightthickness=1,highlightbackground = 'black', background='white') 
    ccol.place(x = 20, y = 90)
    
    img = ImageTk.PhotoImage(file="Images/Image_grille.png")   #Importe l'image de la grille de jeu
    ccol.create_image(-1, -1, image=img, anchor=NW) #AFfiche la grille

# Activer ou desactiver le boutons OK 
def func_act_desact_bouton_de_jeu(x):
    if x == "Activer":
        Bt_OK.config(state = ACTIVE)
        fleche_vers_droite.config(state = ACTIVE)
        fleche_vers_gauche.config(state = ACTIVE)
    if x == "Desactiver":
        Bt_OK.config(state = DISABLED)
        fleche_vers_droite.config(state = DISABLED)
        fleche_vers_gauche.config(state = DISABLED)

# Fait jouer le bot une fois
def func_IA():
    global Liste
    Liste_IA = [0,0,0,0,0,0,0,0]
    colonne = -1
    colonne = func_win()
    
    A_Joue = False 
    if colonne != -1:
        Liste_IA[colonne] = 1

    else:
        colonne = func_lose()
        if colonne != -1:
            Liste_IA[colonne] = 1

        else:
            colonne = func_lose2()
            if colonne != -1:
                Liste_IA[colonne] = -1

    colonne_en_cours = 0
    for i in Liste_IA:
        
        if i == 1 and A_Joue == False:
            for ligne in range(6,-1,-1):
                if Liste[ligne][colonne_en_cours] == 0:
                    colonne_jouee = colonne_en_cours
                    Liste[ligne][colonne_en_cours] = Num_Joueur_IA
                    A_Joue = True
                    break
        colonne_en_cours+=1
  
     # On regarde si on n'a toujours pas joué
    if A_Joue == False:
        a = False
        while a == False:

            # On appelle cette fonction qui joue plus au milieu si on ne trouve nul part de décisif ou jouer
            colonne_en_cours = func_choix_colonne_aleatoire()

            i = Liste_IA[colonne_en_cours]

            if i == 0 and A_Joue == False:
                # On vérifie qu'on peut jouer dans la colonne et si oui on dit qu'on a joué
                for ligne in range(6,-1,-1):
                    if Liste[ligne][colonne_en_cours] == 0:
                        colonne_jouee = colonne_en_cours
                        Liste[ligne][colonne_en_cours] = Num_Joueur_IA
                        A_Joue = True

                        a = True
                        break
    
    func_annimation_jeton(colonne_jouee, Num_Joueur_IA)
    
    if func_verification_gagne(Liste) == True:

        zone_canvas_droite.itemconfigure(text_tour_joueur, text = "Le joueur 2 a gagné")
        
        func_act_desact_bouton_de_jeu("Desactiver")

        func_lier_delier_touches("de-lier")

    else:
        func_changement_joueur_en_cours(Num_Joueur_IA)
        func_affichage_joueur(Joueur_en_cours)

# Première test du bot
def func_win():
    Liste_Jeu_Travail = list(Liste)
    for colonne in range(0,8):
        compteur = 0
        
        for ligne in range(6,-1,-1):
                # Si la case de cette ligne dans cette colonne la est vide
                if Liste_Jeu_Travail[ligne][colonne] == 0 and compteur == 0:

                    # Changer la case par le numero du joueur
                    Liste_Jeu_Travail[ligne][colonne] = Num_Joueur_IA

                    compteur = 1

                    if func_verification_gagne(Liste_Jeu_Travail) == True:
                        Liste_Jeu_Travail[ligne][colonne] = 0
                        return colonne
                    
                    else:
                        Liste_Jeu_Travail[ligne][colonne] = 0
    return -1                    

# Deuxième test du bot
def func_lose():
    Liste_Jeu_Travail = list(Liste)
    
    for colonne in range(0,8):
        compteur = 0
        
        for ligne in range(6,-1,-1):
                # Si la case de cette ligne dans cette colonne la est vide
                if Liste_Jeu_Travail[ligne][colonne] == 0 and compteur == 0:

                    # Changer la case par le numero du joueur
                    Liste_Jeu_Travail[ligne][colonne] = Num_Joueur_Client

                    compteur = 1
                    
                    if func_verification_gagne(Liste_Jeu_Travail) == True:
                        Liste_Jeu_Travail[ligne][colonne] = 0
                        return colonne

                    else:
                        Liste_Jeu_Travail[ligne][colonne] = 0
    return -1

# Troisième test du bot
def func_lose2():
    Liste_Jeu_Travail = list(Liste)
    
    for colonne in range(0,8):
        compteur = 0
        for ligne in range(6,-1,-1):
                # Si la case de cette ligne dans cette colonne la est vide
                if Liste_Jeu_Travail[ligne][colonne] == 0 and compteur == 0:

                    # Changer la case par le numero du joueur
                    if ligne>0:
                        Liste_Jeu_Travail[ligne-1][colonne] = Num_Joueur_Client

                    compteur = 1

                    if func_verification_gagne(Liste) == True:
                        Liste_Jeu_Travail[ligne-1][colonne] = 0
                        return colonne

                    else:
                        if ligne>0:
                            Liste_Jeu_Travail[ligne-1][colonne] = 0
    return -1

# Définition d'une colonne aleatoirement avec plus de probabilitées pour celle du centre    
def func_choix_colonne_aleatoire():
    # Choisit un nombre entre 1 et 10
    a = random.randint(1,10)

    colonne = 0 # Colonne selectionnee de base, la premiere (0)

    # Si 1 -> première ou dernière colonne
    if a == 1:
        colonne = random.choice([0,7])
    # Si 2 ou 3 -> deuxième ou septième colonne
    elif a == 2 or a == 3:
        colonne = random.choice([1,6])
    # Si entre 4 et 6 inclu -> troisième ou sixième colonne
    elif a > 3 and a < 7:
        colonne = random.choice([2,5])
    # Si entre 7 et 10 inclu -> quatrième ou cinquième colonne
    elif a > 6 and a < 11:
        colonne = random.choice([3,4])

    return colonne

# Récupération des valeurs pour la couleur des jetons(si il n'y pas -> couleur par défault)
if __name__ == "__main__":
    # Si valeurs
    try:
        Couleur_J1 = int(sys.argv[1])   # Recup Argument 1
        Couleur_J2 = int(sys.argv[2])   # Recup Argument 2  
        func_couleur_jeton(1, Couleur_J1)   # Regarde a quelle couleur correspond l'argument et change la couleur du jeton
        func_couleur_jeton(2, Couleur_J2)   # ""
        
    # Couleurs par défaults
    except:
        Couleur_Jeton_J1 = "red"
        Couleur_Jeton_J2 = "yellow"  

##### Creation de la fenetre tkinter #####

interface = Tk()
interface.geometry('1000x600')  # Taille de la fenetre
interface.title('Jeu du Puissance 4')   # Titre de la fenetre
interface.config(bg = 'white')  # Couleur du fond de la fenetre

icone = PhotoImage(file = "Images/Logo_ISN.png")   # Icone de la fenêtre
interface.call('wm','iconphoto',interface._w,icone) # Met l'icone

func_creation_affichage()   # Création de l'affichage (le fond)

##### Variables #####

Liste = [[0,0,0,0,0,0,0,0],
         [0,0,0,0,0,0,0,0],
         [0,0,0,0,0,0,0,0],
         [0,0,0,0,0,0,0,0],
         [0,0,0,0,0,0,0,0],
         [0,0,0,0,0,0,0,0],
         [0,0,0,0,0,0,0,0]]

Colonne_selectionnee = 0 
Joueur_en_cours = 1
Num_Joueur_IA = 2
Num_Joueur_Client = 1

### Création des variables correspondant au image des boutons  ###

# Bouton fleche gauche
fleche_G = PhotoImage(file = 'Images/fleche_G.png')    # Importe l'image
fleche_G = fleche_G.subsample(10,10)    # Reduit la taille 

# Bouton fleche droite
fleche_D = PhotoImage(file = 'Images/fleche_D.png')
fleche_D = fleche_D.subsample(10,10)

# Bouton ok
img_OK = PhotoImage(file = 'Images/OK.png')
img_OK = img_OK.subsample(10,10)

# Bouton restart
img_restart = PhotoImage(file = 'Images/restart.png')
img_restart = img_restart.subsample(10,10)

### Création des boutons ###

# Bouton fleche droite
fleche_vers_droite = Button(interface, command = func_fleche_allant_vers_droite, image = fleche_D)
fleche_vers_droite.place(x = 650, y = 250)
fleche_vers_droite.config(state = ACTIVE)

# Bouton fleche gauche
fleche_vers_gauche = Button(interface, command = func_fleche_allant_vers_gauche, image = fleche_G)
fleche_vers_gauche.place(x = 600, y = 250)
fleche_vers_gauche.config(state = ACTIVE)

# Bouton ok
Bt_OK = Button(interface, command = func_ok, image = img_OK)
Bt_OK.place(x = 600, y = 300)
Bt_OK.config(state = ACTIVE)

# Bouton restart
Bt_restart = Button(interface, command = func_restart, image = img_restart)
Bt_restart.place(x = 600, y = 400)
Bt_restart.config(state = ACTIVE)

### Création canvas pour la zone de texte en haut à droite ###

zone_canvas_droite = Canvas(interface, width=300, height=150, highlightthickness=0, background='white')
zone_canvas_droite.place(x = 600, y = 90)

text_attribution_joueur = zone_canvas_droite.create_text(100,10, text = '', font = '50')
text_tour_joueur = zone_canvas_droite.create_text(100,70, text = '', font = '50')

### Création de la fleche qui indique la colonne selectionnée

zone_fleche = Canvas(interface, width = 560, height = 70, highlightthickness = 0, bg = 'white')
zone_fleche.place(x = 20, y = 20)

zone_fleche.create_polygon((5,20,35,55,65,20), fill = 'tan')

### Partie des canvas animation ###

icl = [0,0,0,0,0,0,0,0]

##### Programme #####

func_affichage_joueur(Joueur_en_cours)  # Affiche dans la zone de texte le joueur qui commence
func_lier_delier_touches("lier")    # Lie les touches de jeu (fleches + OK)

interface.mainloop()
